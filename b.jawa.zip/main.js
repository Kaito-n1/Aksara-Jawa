const cards = [
  { aksara: "ꦲ", latin: "Ha" },
  { aksara: "ꦤ", latin: "Na" },
  { aksara: "ꦕ", latin: "Ca" },
  { aksara: "ꦫ", latin: "Ra" },
  { aksara: "ꦏ", latin: "Ka" },
  { aksara: "ꦢ", latin: "Da" },
  { aksara: "ꦠ", latin: "Ta" },
  { aksara: "ꦱ", latin: "Sa" }
];

// Fungsi untuk mengacak urutan kartu
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

shuffle(cards); // Acak sebelum ditampilkan

let current = 0;
const flashcard = document.getElementById("flashcard");
const front = document.getElementById("front");
const back = document.getElementById("back");

function updateCard() {
  front.textContent = cards[current].aksara;
  back.textContent = cards[current].latin;
  flashcard.classList.remove("flipped");
}

function flipCard() {
  flashcard.classList.toggle("flipped");
}

function nextCard() {
  current = (current + 1) % cards.length;
  updateCard();
}

updateCard();
